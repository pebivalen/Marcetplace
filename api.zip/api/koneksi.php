<?php
/**
 * Koneksi khusus REST API untuk pengujian XAMPP.
 * Import database.sql ke database bernama marketplace.
 * Jangan gunakan file ini untuk menyimpan password hosting.
 */
mysqli_report(MYSQLI_REPORT_OFF);

$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'marketplace';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => false,
        'message' => 'Koneksi database gagal. Periksa XAMPP dan konfigurasi api/koneksi.php.',
        'error' => $conn->connect_error
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}
$conn->set_charset('utf8mb4');

header('Content-Type: application/json; charset=utf-8');

function json_response($code, $status, $message, $data = null) {
    http_response_code($code);
    $response = [
        'status' => $status,
        'message' => $message
    ];
    if ($data !== null) {
        $response['data'] = $data;
    }
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}
