<?php
require_once __DIR__ . '/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET');
    json_response(405, false, 'Method tidak diizinkan. Gunakan GET.');
}

$result = $conn->query(
    "SELECT id_kategori, nama_kategori
     FROM kategori
     ORDER BY nama_kategori ASC"
);
if (!$result) json_response(500, false, 'Data kategori gagal diambil.');

$categories = [];
while ($row = $result->fetch_assoc()) $categories[] = $row;

json_response(200, true, 'Daftar kategori berhasil ditampilkan.', $categories);
