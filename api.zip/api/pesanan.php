<?php
require_once __DIR__ . '/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    json_response(405, false, 'Method tidak diizinkan. Gunakan POST.');
}

$raw = file_get_contents('php://input');
$input = json_decode($raw, true);

if (!is_array($input)) {
    json_response(400, false, 'Body harus berupa JSON yang valid.');
}

$id_user = filter_var($input['id_user'] ?? null, FILTER_VALIDATE_INT);
$alamat = trim($input['alamat_pengiriman'] ?? '');
$items = $input['items'] ?? null;

if (!$id_user || $id_user < 1) {
    json_response(400, false, 'id_user wajib diisi dengan angka yang valid.');
}
if ($alamat === '') {
    json_response(400, false, 'alamat_pengiriman wajib diisi.');
}
if (!is_array($items) || count($items) < 1) {
    json_response(400, false, 'items harus berupa array yang berisi minimal satu produk.');
}

try {
    // Pastikan pengguna terdaftar.
    $userStmt = $conn->prepare("SELECT id_user FROM users WHERE id_user = ? LIMIT 1");
    $userStmt->bind_param('i', $id_user);
    $userStmt->execute();
    if (!$userStmt->get_result()->fetch_assoc()) {
        json_response(404, false, 'Pengguna tidak ditemukan.');
    }

    $conn->begin_transaction();

    $validatedItems = [];
    $total = 0;

    foreach ($items as $item) {
        $id_produk = filter_var($item['id_produk'] ?? null, FILTER_VALIDATE_INT);
        $jumlah = filter_var($item['jumlah'] ?? null, FILTER_VALIDATE_INT);

        if (!$id_produk || $id_produk < 1 || !$jumlah || $jumlah < 1) {
            throw new Exception('Setiap item harus memiliki id_produk dan jumlah positif.');
        }

        // Kunci baris produk agar stok tidak berubah saat transaksi berlangsung.
        $productStmt = $conn->prepare(
            "SELECT id_produk, nama_produk, harga, stok
             FROM produk WHERE id_produk = ? FOR UPDATE"
        );
        $productStmt->bind_param('i', $id_produk);
        $productStmt->execute();
        $product = $productStmt->get_result()->fetch_assoc();

        if (!$product) throw new Exception("Produk dengan ID {$id_produk} tidak ditemukan.");
        if ((int)$product['stok'] < $jumlah) {
            throw new Exception("Stok {$product['nama_produk']} tidak mencukupi.");
        }

        $harga = (float)$product['harga'];
        $subtotal = $harga * $jumlah;
        $total += $subtotal;

        $validatedItems[] = [
            'id_produk' => (int)$product['id_produk'],
            'nama_produk' => $product['nama_produk'],
            'jumlah' => $jumlah,
            'harga' => $harga,
            'subtotal' => $subtotal
        ];
    }

    $orderStmt = $conn->prepare(
        "INSERT INTO pesanan (id_user, total_harga, alamat_pengiriman, status)
         VALUES (?, ?, ?, 'Menunggu')"
    );
    $orderStmt->bind_param('ids', $id_user, $total, $alamat);
    $orderStmt->execute();
    $id_pesanan = $conn->insert_id;

    $detailStmt = $conn->prepare(
        "INSERT INTO detail_pesanan (id_pesanan, id_produk, jumlah, harga, subtotal)
         VALUES (?, ?, ?, ?, ?)"
    );
    $stockStmt = $conn->prepare(
        "UPDATE produk SET stok = stok - ? WHERE id_produk = ?"
    );

    foreach ($validatedItems as $item) {
        $pid = $item['id_produk'];
        $qty = $item['jumlah'];
        $price = $item['harga'];
        $subtotal = $item['subtotal'];

        $detailStmt->bind_param('iiidd', $id_pesanan, $pid, $qty, $price, $subtotal);
        $detailStmt->execute();

        $stockStmt->bind_param('ii', $qty, $pid);
        $stockStmt->execute();
    }

    $conn->commit();

    json_response(201, true, 'Pesanan berhasil dibuat dan disimpan.', [
        'id_pesanan' => $id_pesanan,
        'id_user' => $id_user,
        'total_harga' => $total,
        'status' => 'Menunggu',
        'alamat_pengiriman' => $alamat,
        'items' => $validatedItems
    ]);
} catch (Throwable $e) {
    if ($conn->errno || $conn->ping()) {
        try { $conn->rollback(); } catch (Throwable $ignored) {}
    }
    json_response(400, false, $e->getMessage());
}
