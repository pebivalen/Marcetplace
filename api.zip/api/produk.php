<?php
require_once __DIR__ . '/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET');
    json_response(405, false, 'Method tidak diizinkan. Gunakan GET.');
}

$id = isset($_GET['id']) ? filter_var($_GET['id'], FILTER_VALIDATE_INT) : null;

if (isset($_GET['id']) && (!$id || $id < 1)) {
    json_response(400, false, 'Parameter id harus berupa bilangan bulat positif.');
}

if ($id !== null) {
    $stmt = $conn->prepare(
        "SELECT p.id_produk, p.id_kategori, k.nama_kategori,
                p.nama_produk, p.deskripsi, p.harga, p.stok, p.gambar,
                p.created_at
         FROM produk p
         LEFT JOIN kategori k ON k.id_kategori = p.id_kategori
         WHERE p.id_produk = ? LIMIT 1"
    );
    if (!$stmt) json_response(500, false, 'Query gagal disiapkan.');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();

    if (!$product) json_response(404, false, 'Produk tidak ditemukan.');
    json_response(200, true, 'Detail produk berhasil ditampilkan.', $product);
}

$q = trim($_GET['q'] ?? '');
$kategori = isset($_GET['kategori']) ? filter_var($_GET['kategori'], FILTER_VALIDATE_INT) : null;

if (isset($_GET['kategori']) && ($kategori === false || $kategori < 1)) {
    json_response(400, false, 'Parameter kategori harus berupa bilangan bulat positif.');
}

$sql = "SELECT p.id_produk, p.id_kategori, k.nama_kategori,
               p.nama_produk, p.deskripsi, p.harga, p.stok, p.gambar,
               p.created_at
        FROM produk p
        LEFT JOIN kategori k ON k.id_kategori = p.id_kategori
        WHERE 1=1";
$types = '';
$params = [];

if ($q !== '') {
    $sql .= " AND (p.nama_produk LIKE ? OR p.deskripsi LIKE ?)";
    $like = '%' . $q . '%';
    $params[] = $like;
    $params[] = $like;
    $types .= 'ss';
}
if ($kategori !== null) {
    $sql .= " AND p.id_kategori = ?";
    $params[] = $kategori;
    $types .= 'i';
}
$sql .= " ORDER BY p.id_produk DESC";

$stmt = $conn->prepare($sql);
if (!$stmt) json_response(500, false, 'Query produk gagal disiapkan.');
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();

$result = $stmt->get_result();
$products = [];
while ($row = $result->fetch_assoc()) $products[] = $row;

json_response(200, true, 'Daftar produk berhasil ditampilkan.', $products);
