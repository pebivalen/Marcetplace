REST API MARKETKU - SOAL 12

1. PERSIAPAN XAMPP
- Salin folder marketku ke C:\xampp\htdocs\
- Jalankan Apache dan MySQL dari XAMPP Control Panel.
- Buka http://localhost/phpmyadmin
- Buat database bernama marketplace.
- Import file database.sql ke database marketplace.
- Konfigurasi website ada di config/koneksi.php dan konfigurasi API ada di api/koneksi.php. Keduanya sudah disiapkan untuk XAMPP lokal (localhost, root, password kosong, database marketplace). Sesuaikan jika pengaturan XAMPP kamu berbeda.

2. ENDPOINT
GET  http://localhost/marketku/api/produk.php
GET  http://localhost/marketku/api/produk.php?id=1
GET  http://localhost/marketku/api/kategori.php
POST http://localhost/marketku/api/pesanan.php

3. CONTOH POSTMAN
Method: POST
URL: http://localhost/marketku/api/pesanan.php
Headers:
Content-Type: application/json

Body -> raw -> JSON:
{
  "id_user": 1,
  "alamat_pengiriman": "Jl. Merdeka No. 10, Bengkulu",
  "items": [
    {"id_produk": 1, "jumlah": 2},
    {"id_produk": 3, "jumlah": 1}
  ]
}

Catatan:
- id_user harus sudah ada pada tabel users.
- id_produk harus tersedia di tabel produk.
- Jumlah tidak boleh melebihi stok.
- Harga dan subtotal dihitung dari database, bukan dipercaya dari request.
- Pesanan dan detail pesanan disimpan dalam satu transaksi database.
- Pengujian POST akan mengurangi stok produk.

4. PENGUJIAN
- Buka endpoint GET melalui browser.
- Uji POST melalui Postman.
- Setelah POST sukses, periksa tabel pesanan dan detail_pesanan di phpMyAdmin.
- Periksa stok produk karena stok akan berkurang setelah pesanan dibuat.

CATATAN KEAMANAN
Endpoint POST ini memakai id_user dari body untuk kebutuhan demonstrasi tugas lokal.
Untuk aplikasi produksi, identitas pengguna wajib diverifikasi menggunakan autentikasi/token,
bukan mempercayai id_user yang dikirim klien.
Jangan mengunggah password database atau kredensial hosting ke GitHub.
