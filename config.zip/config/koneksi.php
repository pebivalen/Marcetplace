<?php
// Konfigurasi lokal XAMPP untuk pengujian Soal 12.
// Untuk hosting, atur kredensial melalui file konfigurasi privat.
// Jangan commit password database ke GitHub.

mysqli_report(MYSQLI_REPORT_OFF);

$host = "localhost";
$username = "root";
$password = "";
$database = "marketplace";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    http_response_code(500);
    exit("Koneksi database gagal. Periksa Apache, MySQL, dan konfigurasi database lokal.");
}

$conn->set_charset("utf8mb4");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
