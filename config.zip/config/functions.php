<?php
require_once __DIR__ . '/koneksi.php';

function e($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function rupiah($value) { return 'Rp ' . number_format((float)$value, 0, ',', '.'); }
function redirect($url) { header("Location: $url"); exit; }
function flash($message, $type='success') {
    $_SESSION['flash'] = ['message'=>$message, 'type'=>$type];
}
function show_flash() {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash']; unset($_SESSION['flash']);
        echo '<div class="alert alert-'.e($f['type']).' alert-dismissible fade show">'.e($f['message']).'<button class="btn-close" data-bs-dismiss="alert"></button></div>';
    }
}
function current_user() { return $_SESSION['user'] ?? null; }
function require_login() {
    if (!current_user()) { flash('Silakan login terlebih dahulu.', 'warning'); redirect('login.php'); }
}
function require_admin() {
    if (!current_user() || current_user()['role'] !== 'admin') {
        flash('Halaman hanya dapat diakses admin.', 'danger'); redirect('../login.php');
    }
}
function cart_count() {
    $cart = $_SESSION['cart'] ?? [];
    return array_sum(array_map('intval', $cart));
}
function image_url($name) {
    if (!$name) return 'https://placehold.co/600x400?text=MarketKu';
    return 'uploads/' . rawurlencode(basename($name));
}
