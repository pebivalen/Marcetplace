<?php
require_once '../config/functions.php';require_admin();
$id=(int)($_GET['id']??0);$edit=null;if($id){$s=$conn->prepare("SELECT * FROM produk WHERE id_produk=?");$s->bind_param('i',$id);$s->execute();$edit=$s->get_result()->fetch_assoc();if(!$edit)exit('Produk tidak ditemukan.');}
$cats=$conn->query("SELECT * FROM kategori ORDER BY nama_kategori");$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $nama=trim($_POST['nama_produk']??'');$kat=(int)($_POST['id_kategori']??0);$desc=trim($_POST['deskripsi']??'');$harga=(float)($_POST['harga']??0);$stok=(int)($_POST['stok']??0);$gambar=$edit['gambar']??null;
 if($nama===''||$kat<1||$harga<0||$stok<0)$error='Lengkapi data produk dengan benar.';
 if(!$error && !empty($_FILES['gambar']['name'])){
  if($_FILES['gambar']['error']!==UPLOAD_ERR_OK)$error='Upload gambar gagal.';
  else{$ext=strtolower(pathinfo($_FILES['gambar']['name'],PATHINFO_EXTENSION));if(!in_array($ext,['jpg','jpeg','png','webp']))$error='Format gambar harus JPG, PNG, atau WEBP.';elseif($_FILES['gambar']['size']>2*1024*1024)$error='Ukuran gambar maksimal 2 MB.';else{$gambar='produk_'.bin2hex(random_bytes(8)).'.'.$ext;if(!move_uploaded_file($_FILES['gambar']['tmp_name'],__DIR__.'/../uploads/'.$gambar))$error='Gagal menyimpan gambar. Periksa folder uploads.';}}
 }
 if(!$error){if($id){
   $s=$conn->prepare("UPDATE produk SET id_kategori=?,nama_produk=?,deskripsi=?,harga=?,stok=?,gambar=? WHERE id_produk=?");
   $s->bind_param('issdisi',$kat,$nama,$desc,$harga,$stok,$gambar,$id);
  } else {
   $s=$conn->prepare("INSERT INTO produk(id_kategori,nama_produk,deskripsi,harga,stok,gambar) VALUES(?,?,?,?,?,?)");
   $s->bind_param('issdis',$kat,$nama,$desc,$harga,$stok,$gambar);
  }
  if($s->execute()){flash('Data produk berhasil disimpan.');redirect('produk.php');}else $error='Gagal menyimpan produk: '.$conn->error;
 }
}
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Form Produk</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head><body class="bg-light"><div class="container py-4" style="max-width:720px"><div class="card p-4"><h2><?=$id?'Edit':'Tambah'?> Produk</h2><?php if($error):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?><form method="post" enctype="multipart/form-data"><label class="form-label">Nama Produk</label><input class="form-control mb-3" name="nama_produk" value="<?=e($_POST['nama_produk']??$edit['nama_produk']??'')?>" required><label class="form-label">Kategori</label><select class="form-select mb-3" name="id_kategori" required><option value="">Pilih kategori</option><?php while($c=$cats->fetch_assoc()):$selected=(int)($_POST['id_kategori']??$edit['id_kategori']??0)==$c['id_kategori'];?><option value="<?=$c['id_kategori']?>" <?=$selected?'selected':''?>><?=e($c['nama_kategori'])?></option><?php endwhile;?></select><label class="form-label">Deskripsi</label><textarea class="form-control mb-3" name="deskripsi"><?=e($_POST['deskripsi']??$edit['deskripsi']??'')?></textarea><label class="form-label">Harga</label><input class="form-control mb-3" type="number" min="0" name="harga" value="<?=e($_POST['harga']??$edit['harga']??'')?>" required><label class="form-label">Stok</label><input class="form-control mb-3" type="number" min="0" name="stok" value="<?=e($_POST['stok']??$edit['stok']??0)?>" required><label class="form-label">Gambar (JPG/PNG/WEBP, maks 2 MB)</label><input class="form-control mb-3" type="file" name="gambar" accept=".jpg,.jpeg,.png,.webp"><button class="btn btn-primary">Simpan</button> <a class="btn btn-secondary" href="produk.php">Batal</a></form></div></div></body></html>
